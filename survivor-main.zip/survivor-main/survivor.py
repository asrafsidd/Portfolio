"""
SURVIVOR — rules-only Polymarket BTC 5-min agent, built to run inside GitHub Actions.
Code is the law. Adaptation happens in params.json, reviewed via chat.

Control files in repo root (edit from your phone, picked up within ~2 min):
  LIVE         present -> real orders.  absent -> paper trading (default)
  HALT         present -> stop trading and exit the run
  params.json  tunables (bounded below). Hard limits live in HARD and never move.

Env (GitHub Secrets/Variables): POLY_PRIVATE_KEY, POLY_FUNDER, POLY_SIGNATURE_TYPE,
  TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, RUN_SECONDS
"""
import os, re, json, math, time, threading, subprocess, datetime as dt, socket
from concurrent.futures import ThreadPoolExecutor
import requests
socket.setdefaulttimeout(20)

GAMMA, CLOB = "https://gamma-api.polymarket.com", "https://clob.polymarket.com"
# Every 5-minute Up/Down series Polymarket runs. Each asset is its own series; slug pattern <asset>-updown-5m-<epoch>.
ASSETS = {"btc": "BTC", "eth": "ETH", "sol": "SOL", "xrp": "XRP", "doge": "DOGE"}
SERIES = {a: f"{a}-up-or-down-5m" for a in ASSETS}
PREFIX = {a: f"{a}-updown-5m-" for a in ASSETS}
MIN_SHARES = 5          # Polymarket engine minimum per order
STATE_FILE, TRADES_FILE, JOURNAL_FILE, WINDOWS_FILE = "state.json", "trades.jsonl", "journal.md", "windows.jsonl"
DECISIONS_FILE, LESSONS_FILE = "decisions.jsonl", "lessons.json"

# --- the learning loop -------------------------------------------------------------------------
# Every closed trade is classified into three coarse buckets. When a bucket has enough history and is
# clearly losing, entries in that bucket are vetoed. Bounded on purpose: it can only ever stop the agent
# trading something, never loosen a rule, size up, or edit code. Turn off with lessons_enabled = 0.
# A veto must rest on evidence, not noise. The old bar (25 trades, 45% wins, any loss) fired on a bucket
# that was down $2.37 over 29 trades at 44.8% — a coin flip — and blocked all trading. Require a real sample,
# a clearly sub-par win rate, and a loss big enough to matter.
# A lesson is VALIDATED at 40+ trades and EXPERIMENTAL at 15+. Only a validated losing lesson may veto a
# trade; an experimental one can only raise the bar (lower confidence). Lessons never loosen a rule, raise a
# size, or touch risk limits. Set lessons_enabled = 0 in params.json to switch the whole loop off.
VALIDATED_N, EXPERIMENTAL_N = 40, 15
VETO_MAX_WIN, VETO_MAX_PNL = 0.40, -10.0

def buckets_of(sig, left):
    """The pre-entry conditions the record shows actually separate outcomes (audit 2026-09-21, 134 trades)."""
    a = sig.get("ask") or 0
    mv = abs(sig.get("move_bps") or 0)
    try: agree = int(str(sig.get("peers", "0/0")).split("/")[0])
    except Exception: agree = 0
    return ["price<0.45" if a < 0.45 else "price0.45-0.55" if a < 0.55 else "price0.55-0.70" if a < 0.70 else "price0.70+",
            "move<10" if mv < 10 else "move10-20" if mv < 20 else "move20+",
            "left120+" if left >= 120 else "left60-120" if left >= 60 else "left<60",
            "alone" if agree <= 1 else "some-agree" if agree <= 3 else "all-agree"]

def lessons(): return load_json(LESSONS_FILE, {})

def judge(e):
    """Recompute a lesson's status and action from its own evidence."""
    n = e["sample_size"]; wr = e["wins"] / n if n else 0
    e["expectancy"] = round(e["pnl"] / n, 4) if n else 0.0
    e["status"] = "validated" if n >= VALIDATED_N else "experimental" if n >= EXPERIMENTAL_N else "collecting"
    if e["status"] == "validated" and wr < VETO_MAX_WIN and e["pnl"] < VETO_MAX_PNL: e["action"] = "veto"
    elif e["status"] in ("validated", "experimental") and e["expectancy"] < -0.10: e["action"] = "reduce_confidence"
    else: e["action"] = "none"
    return e

def learn(state, p, pnl, why):
    """Fold one outcome into every lesson this trade belonged to, then re-judge them."""
    L = lessons(); ts = now().isoformat(timespec="seconds")
    for b in p.get("buckets", []):
        e = L.get(b) if isinstance(L.get(b), dict) and "sample_size" in L.get(b, {}) else \
            {"condition": b, "sample_size": 0, "wins": 0, "losses": 0, "pnl": 0.0, "created_at": ts}
        e["sample_size"] += 1; e["wins"] += int(pnl > 0); e["losses"] += int(pnl <= 0)
        e["pnl"] = round(e["pnl"] + pnl, 4); e["last_updated"] = ts
        before = e.get("action"); L[b] = judge(e)
        if L[b]["action"] != before and L[b]["action"] != "none":
            journal(f"lesson {b}: now {L[b]['status']}, action {L[b]['action']} ({L[b]['wins']}/{L[b]['sample_size']} won, {L[b]['pnl']:+.2f})")
    r = L.setdefault("_why", {}); r[why] = r.get(why, 0) + 1
    save_json(LESSONS_FILE, L)

def rebuild_lessons():
    """Recompute every lesson from trades.jsonl + decisions.jsonl. lessons.json used to be edited in place and a
    stale copy overwrote the seeded history (2026-09-21), leaving a validated veto un-armed for 48 trades."""
    try:
        trades = [json.loads(l) for l in open(TRADES_FILE) if l.strip()]
        ents = {}
        for l in open(DECISIONS_FILE):
            if l.strip():
                d = json.loads(l)
                if d.get("action") == "ENTER": ents[d["market"]] = d
    except FileNotFoundError: return
    old = lessons(); L = {k: v for k, v in old.items() if k.startswith("_")}
    for x in trades:
        if not x.get("live") or x.get("type") != "MOMENTUM" or (x.get("predicted_edge") or 0) < 0: continue
        e = ents.get(x["slug"])
        if not e or e.get("ask") is None: continue
        for b in buckets_of(e, e.get("time_left_sec") or 999):
            r = L.setdefault(b, {"condition": b, "sample_size": 0, "wins": 0, "losses": 0, "pnl": 0.0, "created_at": x["ts"]})
            r["sample_size"] += 1; r["wins"] += int(x["pnl"] > 0); r["losses"] += int(x["pnl"] <= 0)
            r["pnl"] = round(r["pnl"] + x["pnl"], 4); r["last_updated"] = x["ts"]
    for k, v in L.items():
        if not k.startswith("_"): judge(v)
    save_json(LESSONS_FILE, L)
    armed = [k for k, v in L.items() if not k.startswith("_") and v.get("action") == "veto"]
    journal(f"lessons rebuilt from {len(trades)} trades; vetoes armed: {', '.join(armed) or 'none'}")

def lesson_check(sig, left, P):
    """Before every entry: returns (veto_reason or None, confidence_penalty)."""
    if not P.get("lessons_enabled", 1): return None, 0.0
    L = lessons(); penalty = 0.0
    for b in buckets_of(sig, left):
        e = L.get(b)
        if not isinstance(e, dict) or "action" not in e: continue
        if e["action"] == "veto":
            return (f"{b} lost {e['pnl']:+.2f} over {e['sample_size']} trades ({e['wins']}/{e['sample_size']} won) — validated", 0.0)
        if e["action"] == "reduce_confidence": penalty += 0.05
    return None, penalty

def vetoed(sig, left, P):
    return lesson_check(sig, left, P)[0]

def classify(p, pnl, note):
    """Why did this trade end the way it did? Read from what we already recorded, nothing invented."""
    if pnl > 0: return "won at expiry" if "stop" not in note and "lock" not in note else "won on exit rule"
    if "stop" in note:
        gap = (p.get("stop_at") or 0) - (p.get("exit_bid") or 0)
        if gap > 0.10: return "stop filled far below trigger (book emptied)"
        return "momentum reversed, stop did its job"
    if "lock" in note: return "gave back a gain after reaching the lock level"
    if (p.get("entry_left") or 999) < 30: return "entered too late in the window"
    return "held to expiry and the prediction was wrong"

def decide_log(state, action, sig, **kw):
    """One line per decision — entry, skip or exit — so every action can be explained later."""
    row = {"ts": now().isoformat(timespec="seconds"), "action": action,
           "market": (sig or {}).get("slug", ""), "type": (sig or {}).get("type", ""),
           "ask": (sig or {}).get("ask"), "move_bps": (sig or {}).get("move_bps"),
           "peers": (sig or {}).get("peers"), "confidence": (sig or {}).get("confidence"),
           "edge": (sig or {}).get("gross_edge"), "time_left_sec": (sig or {}).get("time_left_sec"),
           "liquidity_usd": (sig or {}).get("liquidity_usd"),
           "mode": state.get("mode"), "bankroll": round(state.get("bankroll_usd", 0), 2), **kw}
    try:
        with open(DECISIONS_FILE, "a") as f: f.write(json.dumps(row) + "\n")
    except Exception as e: log("decide_log", e)
RUN_SECONDS = int(os.environ.get("RUN_SECONDS", "21000"))
IN_ACTIONS = bool(os.environ.get("GITHUB_ACTIONS"))
PULL_EVERY, COMMIT_EVERY = 120, 600

HARD = {"floor_usd": 20.0, "daily_loss_cap_usd": 15.0, "max_trade_pct": 0.10,
        "max_open_positions": 2, "max_exposure_pct": 0.30}
# V2 brief, 2026-09-22, fresh $40. Protect the capital first, trade second.
# Every entry passes through decide(); there is no forced, arb or recovery path that can skip these.
# If the 5-share minimum exceeds 10% of bankroll the trade is skipped (MIN_ORDER_BLOCK) — never resized up.
BOUNDS = {"min_edge": (0.01, 0.08), "max_trade_pct": (0.02, 0.15), "momentum_min_confidence": (0.40, 0.85),
          "momentum_window_sec": (10, 240), "max_open_positions": (1, 2), "min_liquidity_usd": (20, 200),
          "fees": (0.0, 0.05), "slippage": (0.0, 0.05), "momentum_min_move_bps": (3, 30),
          "momentum_max_ask": (0.45, 0.95), "min_order_usd": (1.0, 5.0), "fee_rate": (0.0, 0.10),
          "take_profit_bid": (0.90, 1.0), "stop_loss_bid": (0.05, 0.50), "stop_loss_min_left_sec": (3, 60),
          "momentum_min_ask": (0.10, 0.60), "forced_at_sec": (20, 120), "forced_max_ask": (0.60, 0.95),
          "lock_from_bid": (0.60, 0.95), "lock_giveback": (0.10, 0.50), "stop_frac_of_entry": (0.3, 0.9), "stop_grace_sec": (0, 120), "stop_confirm_ticks": (1, 5), "min_sell_bid": (0.0, 0.40),
          "max_edge": (0.10, 1.0), "arb_enabled": (0, 1), "lessons_enabled": (0, 1), "min_entry_left_sec": (20, 150)}
DEFAULT_PARAMS = {"min_edge": 0.03, "max_trade_pct": 0.10, "momentum_min_confidence": 0.70,
                  "momentum_window_sec": 20, "max_open_positions": 2, "min_liquidity_usd": 50,
                  "fees": 0.0, "slippage": 0.01, "momentum_min_move_bps": 8, "momentum_max_ask": 0.85,
                  "min_order_usd": 1.0, "fee_rate": 0.07,
                  "take_profit_bid": 0.97, "stop_loss_bid": 0.25, "stop_loss_min_left_sec": 8, "momentum_min_ask": 0.40,
                  "forced_at_sec": 0, "forced_max_ask": 0.92, "lessons_enabled": 1, "min_entry_left_sec": 120, "lock_from_bid": 0.85, "lock_giveback": 0.25, "stop_frac_of_entry": 0.6, "stop_grace_sec": 45, "stop_confirm_ticks": 3, "min_sell_bid": 0.15, "max_edge": 0.20, "arb_enabled": 0}

# Paper-only exploration: loose thresholds so the log fills fast. Live ignores this entirely.
EXPLORE = {"momentum_min_move_bps": 3, "momentum_min_confidence": 0.55, "momentum_window_sec": 45,
           "momentum_max_ask": 0.90, "max_open_positions": 3, "min_liquidity_usd": 20}
def params():
    P = load_params()
    if not is_live(): P.update(EXPLORE)
    return P

def fee(p, P):
    """Polymarket crypto_fees_v2: taker pays rate * p * (1-p) per share; makers pay nothing."""
    return P["fee_rate"] * p * (1 - p)

def now(): return dt.datetime.now(dt.timezone.utc)
def today(): return now().date().isoformat()
def parse(s): return dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
def log(*a): print(now().strftime("%H:%M:%S"), *a, flush=True)
LIVE_BLOCKED = False   # set when LIVE is requested but Polymarket auth/balance fails; falls back to paper and pings you
def is_live(): return os.path.exists("LIVE") and not LIVE_BLOCKED

# ---------- telegram ----------
def notify(msg):
    tok, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat: return
    try: requests.post(f"https://api.telegram.org/bot{tok}/sendMessage", json={"chat_id": chat, "text": msg}, timeout=10)
    except Exception as e: log("telegram fail", e)

# ---------- files & git ----------
def load_json(p, default):
    try: return json.load(open(p))
    except Exception: return default
def save_json(p, d):
    if p == STATE_FILE: d["hard_limits"] = HARD      # dashboard reads the real limits from here
    json.dump(d, open(p, "w"), indent=1)
def load_params():
    p = dict(DEFAULT_PARAMS); p.update(load_json("params.json", {}))
    for k, (lo, hi) in BOUNDS.items(): p[k] = min(hi, max(lo, p.get(k, DEFAULT_PARAMS[k])))
    return p
def journal(line):
    with open(JOURNAL_FILE, "a") as f: f.write(f"- {now().isoformat(timespec='seconds')} {line}\n")
def git(*a): return subprocess.run(["git", *a], capture_output=True, text=True)
RESTART = False
BOT_FILES = (STATE_FILE, TRADES_FILE, JOURNAL_FILE, WINDOWS_FILE, DECISIONS_FILE, LESSONS_FILE)
_push_fails = 0

def pull():
    """Take everything pushed from outside (code, params, LIVE/HALT/RELAY) while keeping the agent's own records.
    The old `git pull --rebase` could hit a conflict on state.json at a handover, leave the repo mid-rebase, and
    silently fail every save for the rest of the run: on 2026-09-21 a run traded for 50 minutes and none of it
    reached the repo. The agent is the only writer of BOT_FILES, so its local copies always win for those."""
    global RESTART
    if not IN_ACTIONS: return
    git("rebase", "--abort"); git("merge", "--abort")                     # clear anything left stuck
    if git("fetch", "-q", "origin", "main").returncode: return
    code_before = git("rev-parse", "HEAD:survivor.py").stdout.strip()
    wf_before = git("rev-parse", "HEAD:.github/workflows/survivor.yml").stdout.strip()
    APPEND_ONLY = (TRADES_FILE, JOURNAL_FILE, WINDOWS_FILE, DECISIONS_FILE)
    keep = {}
    for f in BOT_FILES:
        try: keep[f] = open(f, "rb").read()
        except FileNotFoundError: pass
    git("reset", "-q", "--hard", "origin/main")
    for f, data in keep.items():
        if f in APPEND_ONLY:
            # These only ever grow. Replacing them wholesale let a run holding an older copy erase newer
            # records (2026-09-29: trades vanished between reads and the ledger stopped matching the balance).
            # Union the two, keeping first-seen order, so nothing can be lost from either side.
            try: remote = open(f, "rb").read()
            except FileNotFoundError: remote = b""
            seen, merged = set(), []
            for line in remote.split(b"\n") + data.split(b"\n"):
                if line.strip() and line not in seen:
                    seen.add(line); merged.append(line)
            with open(f, "wb") as fh: fh.write(b"\n".join(merged) + (b"\n" if merged else b""))
        else:
            with open(f, "wb") as fh: fh.write(data)
    code_after = git("rev-parse", "HEAD:survivor.py").stdout.strip()
    wf_after = git("rev-parse", "HEAD:.github/workflows/survivor.yml").stdout.strip()
    if (code_before and code_after and code_before != code_after) or (wf_before and wf_after and wf_before != wf_after):
        RESTART = True

def commit(state, msg="survivor: state"):
    global _push_fails
    save_json(STATE_FILE, state)
    for f in BOT_FILES:
        if not os.path.exists(f): open(f, "a").close()   # git add fails outright on a missing path
    if not IN_ACTIONS: return
    pull()                                                   # sit on top of the latest remote before committing
    a = git("add", "--", *BOT_FILES)
    if a.returncode: log("git add failed", a.stderr[-200:]); return
    if git("commit", "-q", "-m", msg).returncode: return    # nothing changed
    r = git("push", "-q", "origin", "HEAD:main")     # explicit target: never depends on upstream tracking
    if r.returncode:
        _push_fails += 1
        log("push failed", r.stderr[-300:])
        if _push_fails in (3, 30):     # the journal can't carry this message — it is the thing not arriving
            notify(f"Agent is trading but can't save its records to GitHub ({_push_fails} failed pushes): {r.stderr.strip()[-150:]}")
    else:
        _push_fails = 0

# ---------- polymarket (unified SDK: Deposit Wallet / pUSD, V2 CLOB) ----------
_pm, _pm_relay = None, None
def _install_bypass():
    """Vercel's free plan keeps a login wall on the relay URL; VERCEL_BYPASS is its official automation key.
    Attach it to every httpx client that targets the relay (the SDK builds its own clients, so hook the constructor)."""
    key = os.environ.get("VERCEL_BYPASS")
    if getattr(_install_bypass, "done", False): return
    import httpx
    orig = httpx.Client.__init__
    def patched(self, *a, **kw):
        kw["timeout"] = httpx.Timeout(20.0)           # never let one relay call hang the whole loop
        orig(self, *a, **kw)
        base = str(kw.get("base_url") or "")
        if key and "vercel.app" in base: self.headers["x-vercel-protection-bypass"] = key
    httpx.Client.__init__ = patched; _install_bypass.done = True
def _bypass_headers():
    key = os.environ.get("VERCEL_BYPASS"); return {"x-vercel-protection-bypass": key} if key else {}

def relay_url():
    """Public URL of the Vercel relay (file RELAY). GitHub runners are US IPs and Polymarket geoblocks order
    placement from there, so every CLOB call is routed through the relay in Dublin."""
    try: return open("RELAY").read().strip() or None
    except Exception: return None

def pm():
    """Authenticated client, CLOB traffic via the relay. Rebuilt whenever the relay URL changes."""
    global _pm, _pm_relay
    relay = relay_url()
    if _pm is None or relay != _pm_relay:
        _install_bypass()
        import dataclasses
        from polymarket import SecureClient
        from polymarket.environments import PRODUCTION, _create_environment
        env = PRODUCTION
        if relay: env = _create_environment(name="relay", config=dataclasses.replace(PRODUCTION._config, clob_url=relay))
        _pm = SecureClient.create(private_key=os.environ["POLY_PRIVATE_KEY"], wallet=os.environ["POLY_FUNDER"], environment=env)
        _pm_relay = relay
        log("polymarket", _pm.wallet_type, str(_pm.wallet)[:10], "via relay" if relay else "DIRECT (orders will be geoblocked)")
    return _pm

def live_balance():
    """pUSD balance of the account wallet, in dollars."""
    r = pm().get_balance_allowance(asset_type="COLLATERAL")
    return r.balance / 1e6

def diagnose_funds():
    """Where is the money? SDK view of the wallet + on-chain pUSD/USDC.e of the account wallet."""
    out = []
    try:
        c = pm(); out.append(f"wallet_type={c.wallet_type} wallet={str(c.wallet)[:6]}…{str(c.wallet)[-4:]} signer={str(c.signer)[:6]}…{str(c.signer)[-4:]}")
        r = c.get_balance_allowance(asset_type="COLLATERAL"); out.append(f"clob pUSD balance={r.balance / 1e6:.2f} allowances={len(r.allowances)}")
        try: out.append(f"approvals={c.get_trading_approvals_state()}"[:120])
        except Exception as e: out.append(f"approvals err {str(e)[:60]}")
    except Exception as e: out.append(f"sdk err {str(e)[:100]}")
    funder = os.environ.get("POLY_FUNDER", "")
    tokens = {"pUSD": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB", "USDC.e": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"}
    rpcs = ["https://polygon-bor-rpc.publicnode.com", "https://rpc.ankr.com/polygon", "https://polygon-rpc.com"]
    for tname, taddr in tokens.items():
        data = "0x70a08231" + funder[2:].lower().rjust(64, "0"); got = None; last = ""
        for rpc in rpcs:
            try:
                r = requests.post(rpc, json={"jsonrpc": "2.0", "id": 1, "method": "eth_call", "params": [{"to": taddr, "data": data}, "latest"]}, timeout=10).json()
                if "result" in r: got = int(r["result"], 16) / 1e6; break
                last = str(r.get("error", r))[:60]
            except Exception as e: last = str(e)[:60]
        out.append(f"onchain {tname}={got:.2f}" if got is not None else f"onchain {tname} err {last}")
    journal("funds check: " + " | ".join(out)); notify("funds check: " + " | ".join(out))

def _resp(r):
    ok = bool(getattr(r, "ok", False))
    return ok, (f"{r.order_id} {r.status}" if ok else f"{getattr(r, 'code', '?')}: {getattr(r, 'message', r)}")[:160]

def buy(token_id, usd):
    """Market buy spending `usd` pUSD. FAK, not FOK: a thin book gives a smaller position instead of no trade."""
    if not is_live(): return True, "paper"
    for attempt in range(2):
        try:
            ok, resp = _resp(pm().place_market_order(token_id=token_id, side="BUY", amount=str(round(usd, 2)), order_type="FAK"))
        except Exception as e:
            ok, resp = False, str(e)[:160]
        if ok or "no orders found" not in str(resp): return ok, resp
        time.sleep(0.7)          # the book refills within a second; one retry, then give up
    return False, resp

def held_shares(token_id):
    """Actual on-chain size for a token — fills can be partial, so our own record can overstate it."""
    try:
        r = requests.get("https://data-api.polymarket.com/positions", params={"user": os.environ["POLY_FUNDER"], "sizeThreshold": 0, "limit": 100}, timeout=15).json()
        for pos in r if isinstance(r, list) else []:
            if str(pos.get("asset")) == str(token_id): return float(pos.get("size", 0))
    except Exception as e: log("held err", e)
    return None

def sell(token_id, shares):
    """Market sell. Rounds DOWN (asking for one cent more than we hold gets the whole order rejected), and if the
    exchange still reports a smaller balance, retries with exactly what it says we have."""
    if not is_live(): return True, "paper"
    real = held_shares(token_id)
    if real is not None and real >= 1:
        shares = min(shares, real)
    # If the API shows <1 share it is usually still indexing our fill. Sell what we recorded; if we really hold
    # less, the exchange rejects with the true balance and the retry below uses exactly that.
    for attempt in range(3):
        size = math.floor(shares * 100) / 100                    # never round up
        if size < 1: return False, f"size too small ({shares})"
        try: ok, resp = _resp(pm().place_market_order(token_id=token_id, side="SELL", shares=str(size), order_type="FAK"))
        except Exception as e: ok, resp = False, str(e)[:200]
        if ok: return True, resp
        m = re.search(r"balance:\s*(\d+)", str(resp))           # the error tells us the true size, in 1e6 units
        if m and attempt < 2:
            shares = float(m.group(1)) / 1e6
            log("sell retry with exchange-reported size", shares); continue
        return False, str(resp)[:160]
    return False, "sell retries exhausted"

def spots():
    """Spot USD for every asset in one call (Coinbase exchange rates are USD->coin, so invert)."""
    out = {}
    try:
        rates = requests.get("https://api.coinbase.com/v2/exchange-rates", params={"currency": "USD"}, timeout=5).json()["data"]["rates"]
        for a, sym in ASSETS.items():
            if sym in rates and float(rates[sym]) > 0: out[a] = 1 / float(rates[sym])
    except Exception as e: log("spot err", e)
    if "btc" not in out:   # fallback so BTC never goes dark
        try: out["btc"] = float(requests.get("https://api.coinbase.com/v2/prices/BTC-USD/spot", timeout=5).json()["data"]["amount"])
        except Exception: pass
    return out
def spot(): return spots().get("btc")

_mcache = {}
def markets():
    """All 5-min Up/Down markets across assets. Gamma /markets hides these series; events?series_slug is reliable. Cached 30s."""
    out, t = [], time.time()
    for a in ASSETS:
        c = _mcache.get(a)
        if not c or t - c[0] > 30:
            try:
                r = requests.get(f"{GAMMA}/events", params={"series_slug": SERIES[a], "closed": "false", "limit": 20,
                                                           "order": "endDate", "ascending": "true"}, timeout=10).json()
            except Exception as e: log("markets err", a, e); r = []
            ms = []
            for ev in r or []:
                slug = ev.get("slug", "")
                if not slug.startswith(PREFIX[a]): continue
                m = (ev.get("markets") or [None])[0]
                if not m: continue
                try:
                    toks, outs = json.loads(m["clobTokenIds"]), json.loads(m["outcomes"])
                    up, down = toks[outs.index("Up")], toks[outs.index("Down")]
                except Exception: continue
                tail = slug.rsplit("-", 1)[-1]
                if tail.isdigit(): start = dt.datetime.fromtimestamp(int(tail), dt.timezone.utc); end = start + dt.timedelta(minutes=5)
                else: start, end = parse(m["startDate"]), parse(m["endDate"])
                ms.append({"asset": a, "slug": slug, "start": start, "end": end, "up": up, "down": down})
            _mcache[a] = (t, ms)
        out += _mcache[a][1]
    return out

_pool = ThreadPoolExecutor(max_workers=12)
_session = requests.Session()

def _safe_top(token):
    try: return top(token)
    except Exception: return (None, 0.0, None, 0.0)

def tops(tokens):
    """Fetch every order book at once. One-at-a-time fetches cost ~2s per scan, nearly all of it waiting."""
    return dict(zip(tokens, _pool.map(_safe_top, tokens)))

def top(token):
    """(best ask, $ at ask, best bid) for a token."""
    b = _session.get(f"{CLOB}/book", params={"token_id": token}, timeout=5).json()
    asks = [(float(a["price"]), float(a["size"])) for a in b.get("asks", [])]
    bids = [float(a["price"]) for a in b.get("bids", [])]
    ask, liq, sz = (min(asks)[0], round(min(asks)[0] * min(asks)[1], 2), min(asks)[1]) if asks else (None, 0.0, 0.0)
    return ask, liq, (max(bids) if bids else None), sz

# ---------- brain (rules) ----------
def new_state(bankroll):
    return {"hard_limits": HARD, "bankroll_usd": bankroll, "start_bankroll_usd": bankroll, "peak_bankroll_usd": bankroll,
            "today": today(), "today_pnl_usd": 0.0, "consecutive_losses": 0, "consecutive_wins": 0,
            "mode": "NORMAL", "open_positions": [], "closed_trades": 0, "opens": {},
            "stats": {"wins": 0, "losses": 0, "pnl": 0.0, "arb": 0, "momentum": 0}}

def day_roll(state):
    if state["today"] != today():
        state["today"], state["today_pnl_usd"] = today(), 0.0
        state["peak_bankroll_usd"] = equity(state)      # drawdown is measured from today, not from an all-time high
        state["consecutive_losses"] = min(state["consecutive_losses"], 2)
        journal("day rolled")

def equity(state):
    """Cash plus what's tied up in open positions — a buy moves cash into a position, it isn't a loss."""
    return state["bankroll_usd"] + sum(p["stake"] for p in state["open_positions"])

def set_mode(state):
    if state["mode"] == "DEAD": return
    old = state["mode"]; eq = equity(state)
    if eq <= HARD["floor_usd"] and state.get("bad_reads", 0) == 0 and state.get("closed_trades", 0) > 0:
        state["mode"] = "DEAD"
    elif state["today_pnl_usd"] <= -HARD["daily_loss_cap_usd"]: state["mode"] = "HIBERNATE"
    elif state["consecutive_losses"] >= 2 or (state.get("peak_bankroll_usd", 0) > 0 and 1 - eq / state["peak_bankroll_usd"] > 0.10):
        state["mode"] = "CAUTIOUS"      # a zero peak (startup read of 0.00) used to throw here and freeze the mode
    elif state["consecutive_wins"] >= 3 or old == "NORMAL": state["mode"] = "NORMAL"
    else: state["mode"] = "CAUTIOUS"
    if state["mode"] != old:
        journal(f"mode {old} -> {state['mode']}"); notify(f"mode {old} -> {state['mode']}")

def scan(state, P):
    sigs, sp, t = [], spots(), now()
    ms = markets()
    live_ms = [m for m in ms if 0 < (m["end"] - t).total_seconds() <= 330 and m["asset"] in sp]
    books_now = tops([tok for m in live_ms for tok in (m["up"], m["down"])])   # one parallel round trip
    diag = {"markets": len(ms), "in_window": len(live_ms), "assets": sorted({m["asset"] for m in ms}),
            "best_sum": None, "slug": "", "hot": False, "spot": sp.get("btc"),
            "blocked": {}, "closest": None}
    def block(why): diag["blocked"][why] = diag["blocked"].get(why, 0) + 1
    # first pass: every asset's move this window, so each market can see whether its peers agree
    moves = {}
    for m in live_ms:
        if m["slug"] not in state["opens"] and abs((t - m["start"]).total_seconds()) <= 6: state["opens"][m["slug"]] = sp[m["asset"]]
        op = state["opens"].get(m["slug"])
        if op: moves[m["asset"]] = (sp[m["asset"]] - op) / op * 1e4
    for m in live_ms:
        left = (m["end"] - t).total_seconds(); px = sp[m["asset"]]
        if left <= P["momentum_window_sec"] + 15 or left >= 290: diag["hot"] = True
        ua, ul, ub, usz = books_now.get(m["up"], (None, 0.0, None, 0.0))
        da, dl, db, dsz = books_now.get(m["down"], (None, 0.0, None, 0.0))
        state.setdefault("books", {})[m["slug"]] = {"up": [ua, ub], "down": [da, db], "left": round(left), "up_tok": m["up"], "down_tok": m["down"], "end": m["end"].isoformat()}
        # Near the close one side's asks often vanish (the winner gets hoarded). Keep recording; only skip what needs both sides.
        if left <= 300:  # window dataset: every ~10s, tightening to ~5s in the final 75s
            snaps = state.setdefault("snaps", {}).setdefault(m["slug"], {"asset": m["asset"], "end": m["end"].isoformat(), "open": state["opens"].get(m["slug"]), "s": []})
            if snaps["open"] is None and state["opens"].get(m["slug"]): snaps["open"] = state["opens"][m["slug"]]
            if not snaps["s"] or snaps["s"][-1]["t"] - left >= (5 if left <= 75 else 10):
                op = snaps["open"]
                snaps["s"].append({"t": round(left), "up": ua, "down": da, "mv": round((px - op) / op * 1e4, 1) if op else None})
        base = {"slug": m["slug"], "end": m["end"].isoformat(), "time_left_sec": round(left)}
        if ua is not None and da is not None:
            if diag["best_sum"] is None or ua + da < diag["best_sum"]: diag["best_sum"], diag["slug"] = round(ua + da, 3), m["slug"]
            gross = round(1 - (ua + da) - fee(ua, P) - fee(da, P), 4)
            if False:   # arb removed: full arbs +$5.47, half-filled legs -$19.89. One side only.
                sigs.append({**base, "type": "ARB", "asset": m["asset"], "up": m["up"], "down": m["down"], "up_ask": ua, "down_ask": da,
                             "gross_edge": gross, "liquidity_usd": min(ul, dl), "liq_shares": min(usz, dsz), "confidence": 1.0})
        op = state["opens"].get(m["slug"])
        if not op: block("no opening price captured")
        elif left > P["momentum_window_sec"]: block(f"outside the last {P['momentum_window_sec']}s")
        if op and left <= P["momentum_window_sec"]:
            mv = (px - op) / op * 1e4
            up_side = mv > 0
            ask, liq = (ua, ul) if up_side else (da, dl)
            # Win rate measured on 865 recorded windows, keyed on where the market prices the favoured side.
            # (0.40-0.55: 57%, 0.55-0.65: 67%, 0.65-0.75: 70%, 0.75-0.85: 83%.) A move-only score can never
            # justify an 0.80 ask, which is why that band — the best one — never traded.
            a = abs(mv)
            _ask = ua if up_side else da
            if _ask is None: conf = 0.0
            elif _ask < 0.40: conf = 0.45
            elif _ask < 0.55: conf = 0.57
            elif _ask < 0.65: conf = 0.67
            elif _ask < 0.75: conf = 0.70
            elif _ask < 0.85: conf = 0.83
            else: conf = 0.83
            if a < 6: conf -= 0.10                       # weak move: the band's base rate isn't earned
            peers = [v for a2, v in moves.items() if a2 != m["asset"]]
            agree = sum(1 for v in peers if (v > 0) == up_side and abs(v) >= P["momentum_min_move_bps"] / 2)
            against = sum(1 for v in peers if (v > 0) != up_side and abs(v) >= P["momentum_min_move_bps"] / 2)
            # Live evidence: every "peers 4/0" entry lost (4 of 4). When the whole group moves together it is a
            # macro tick already in the price, and we buy the top of the spike. Broad agreement now costs confidence.
            # The penalty for peers agreeing is gone: across 2,209 windows a crowd move of 4-10 bps wins 75%
            # at +0.049/share, the best bucket in the data. Only peers moving the OTHER way count against us.
            conf = max(0.0, min(0.90, conf - 0.05 * against))
            # Earlier this refused every crowd move outright, on 51 live trades that were mostly forced entries
            # at 0.85+ with broken stops. Across 2,209 clean windows a crowd move of 4-10 bps is the single best
            # setup we have: 256 cases, 75% wins, +0.049/share. The mild penalty above is enough.
            # record the reason this market did not qualify — the heartbeat reports the tally
            if left < P["min_entry_left_sec"]: block("too late in the window")   # late entries chase a move already priced
            elif ask is None: block("no ask")

            elif abs(mv) < P["momentum_min_move_bps"]: block(f"move under {P['momentum_min_move_bps']} bps")
            elif ask < P["momentum_min_ask"]: block("side too cheap (market disagrees)")
            elif ask > P["momentum_max_ask"]: block("side too dear")
            elif conf < P["momentum_min_confidence"]: block("confidence too low")
            elif conf - ask - fee(ask, P) - P["slippage"] < P["min_edge"]: block("edge too thin")
            else:
                nm = round(conf - ask - fee(ask, P) - P["slippage"], 4)
                if diag["closest"] is None or nm > diag["closest"][1]: diag["closest"] = (m["asset"], nm)
            if left >= P["min_entry_left_sec"] and ask is not None and abs(mv) >= P["momentum_min_move_bps"] and P["momentum_min_ask"] <= ask <= P["momentum_max_ask"]:
                sigs.append({**base, "type": "MOMENTUM", "asset": m["asset"], "token": m["up"] if up_side else m["down"],
                             "outcome": 0 if up_side else 1, "ask": ask, "gross_edge": round(conf - ask - fee(ask, P), 4),
                             "liquidity_usd": liq, "confidence": round(conf, 3), "move_bps": round(mv, 1), "peers": f"{agree}/{against}"})
    state["opens"] = dict(list(state["opens"].items())[-60:])
    state["books"] = dict(list(state.get("books", {}).items())[-12:])
    diag["hot"] = diag["hot"] or any(0 < (m["end"] - t).total_seconds() <= 75 for m in live_ms)
    state["diag"] = diag
    return sigs

def unhealthy(state):
    """If we cannot trust balance, records or the relay, we do not guess — we stop opening positions."""
    why = []
    if state.get("bad_reads", 0) >= 3: why.append("balance readings unconfirmed")
    if state.get("settle_fails", 0) >= 5: why.append("settlement failing")
    if _push_fails >= 3: why.append("records not reaching GitHub")
    if state.get("pending_read") is not None: why.append("balance change awaiting confirmation")
    if os.path.exists("LIVE") and not relay_url(): why.append("no relay")
    return ", ".join(why)

def decide(state, P, sigs):
    if state["mode"] in ("DEAD", "HIBERNATE"): return []
    sick = unhealthy(state)
    if sick:
        if state.get("sick_note") != sick:
            journal(f"not opening positions: {sick}"); notify(f"Paused new entries: {sick}")
            state["sick_note"] = sick
        return []
    state["sick_note"] = None
    caut = state["mode"] == "CAUTIOUS"
    # CAUTIOUS already halves the stake; raising the entry bar on top of that was a second penalty for the
    # same losing streak and shut the 0.65-0.85 band out entirely. Smaller size is the caution now.
    min_edge = P["min_edge"]
    room = min(HARD["max_open_positions"], P["max_open_positions"]) - sum(1 for p in state["open_positions"] if p["type"] != "ARB")
    arb_room = HARD["max_open_positions"] - sum(1 for p in state["open_positions"] if p["type"] == "ARB")
    taken = {p["slug"] for p in state["open_positions"]} | set(state.get("traded", []))
    orders = []
    # Today, solo cycles went 7 for 7 (+$10.20) and multi-coin cycles went 0 for 5 (-$11.16). Coins in one window
    # are the same bet, so take the single best and skip a cycle a stop already declared wrong.
    # A cycle is blocked only for the direction already taken. Every multi-coin loss in the record was several
    # coins moving the SAME way — one bet placed twice. Opposite directions in one window are independent bets,
    # and the 2-position cap still bounds them.
    open_cycles = {(p["slug"].rsplit("-", 1)[-1], p.get("legs", [{}])[0].get("outcome")) for p in state["open_positions"]}
    dead = state.get("bad_cycle")
    def rank(x):
        return (x["type"] != "ARB", -x["gross_edge"])     # best expected value first
    n_mom = 1
    for s in sorted(sigs, key=rank):
        cyc = s["slug"].rsplit("-", 1)[-1]
        if s["type"] != "ARB":
            if dead and [cyc, s.get("outcome")] == list(dead): continue   # that side of this tick already stopped out
            if (cyc, s.get("outcome")) in open_cycles: continue   # already holding this side of this window

        if s["type"] == "ARB" and (arb_room <= 0 or not P.get("arb_enabled", 1)): continue
        if s["type"] != "ARB" and room <= 0: continue
        if s["slug"] in taken: continue
        net = s["gross_edge"] - P["fees"] - (0 if s["type"] == "ARB" else P["slippage"])   # arb is FOK at the quoted ask: no slippage term
        if net < (P["min_edge"] if s["type"] == "ARB" else min_edge): continue        # CAUTIOUS doesn't apply to riskless arb
        if s["type"] == "MOMENTUM" and (s["liquidity_usd"] < P["min_liquidity_usd"] or s["confidence"] < P["momentum_min_confidence"]): continue
        # an implausibly large edge means the market strongly disagrees with our feed — those lost 100% every time
        if s["type"] == "MOMENTUM" and not s.get("forced") and net > P["max_edge"]:
            decide_log(state, "SKIP", s, reason=f"edge {net:.2f} implausibly large — the market disagrees too hard"); continue
        if s["type"] == "MOMENTUM":
            v, penalty = lesson_check(s, s.get("time_left_sec", 999), P)
            if v: decide_log(state, "SKIP", s, reason="LESSON_VETO: " + v); continue
            if penalty and s["confidence"] - penalty < P["momentum_min_confidence"]:
                decide_log(state, "SKIP", s, reason=f"LESSON_CAUTION: experimental losing pattern lowers confidence by {penalty:.2f}"); continue
        unit = (s["up_ask"] + s["down_ask"]) if s["type"] == "ARB" else s["ask"]
        if s["type"] == "ARB":
            shares = int(min(state["bankroll_usd"] * min(HARD["max_trade_pct"], P["max_trade_pct"]) / unit, s["liq_shares"] * 0.5))   # both legs must fill: never more than half the thinner book
            if shares < MIN_SHARES: continue
            stake = shares * unit
        else:
            stake = state["bankroll_usd"] * min(HARD["max_trade_pct"], P["max_trade_pct"]) * s["confidence"] * (0.5 if caut else 1.0)
            stake = min(stake / n_mom, s["liquidity_usd"] * 0.8)    # coins firing together are one bet split across them
            stake = max(stake, MIN_SHARES * unit)                   # engine rejects < 5 shares
            cap = state["bankroll_usd"] * min(HARD["max_trade_pct"], P["max_trade_pct"])
            open_now = sum(p["stake"] for p in state["open_positions"])
            room_left = state["bankroll_usd"] * HARD["max_exposure_pct"] - open_now
            if room_left < MIN_SHARES * unit:
                decide_log(state, "SKIP", s, reason=f"EXPOSURE_CAP: {open_now:.2f} already at risk, "
                                                   f"only {max(0,room_left):.2f} of the {HARD['max_exposure_pct']:.0%} budget left")
                continue
            cap = min(cap, room_left)
            if MIN_SHARES * unit > cap + 0.01:
                decide_log(state, "SKIP", s, reason=f"MIN_ORDER_BLOCK: 5 shares costs {MIN_SHARES*unit:.2f}, over the {cap:.2f} cap")
                continue
            if stake > cap + 0.01 or stake > state["bankroll_usd"]: continue
        if state["bankroll_usd"] - stake < HARD["floor_usd"]:
            if not state.get("floor_logged"):
                decide_log(state, "SKIP", s, reason=f"BANKROLL_FLOOR: {state['bankroll_usd']:.2f} minus a {stake:.2f} ticket would go under the ${HARD['floor_usd']:.0f} floor")
                journal(f"BANKROLL_FLOOR: {state['bankroll_usd']:.2f} is too close to the ${HARD['floor_usd']:.0f} floor to open any position — scanning only")
                state["floor_logged"] = True
            continue
        state["floor_logged"] = False
        orders.append((s, round(stake, 2), round(net, 4))); taken.add(s["slug"])
        if s["type"] == "ARB": arb_room -= 1
        else: room -= 1; open_cycles.add((s["slug"].rsplit("-", 1)[-1], s.get("outcome")))
    return orders

def execute(state, s, stake, net, P):
    legs = []
    if s["type"] == "ARB":
        shares = int(stake / (s["up_ask"] + s["down_ask"]))
        order = sorted(((s["up"], s["up_ask"], 0), (s["down"], s["down_ask"], 1)), key=lambda x: -x[1])  # likely winner first
        for tok, ask, idx in order:
            usd = round(shares * ask, 2); ok, resp = buy(tok, usd)
            legs.append({"token": tok, "outcome": idx, "shares": float(shares), "cost": usd, "ok": ok, "resp": resp})
            if not ok: break
    else:
        ok, resp = buy(s["token"], stake)
        legs.append({"token": s["token"], "outcome": s["outcome"], "shares": round(stake / s["ask"], 4), "cost": stake, "ok": ok, "resp": resp})
    filled = [l for l in legs if l["ok"]]
    if not filled:
        journal(f"order failed {s['type']} {s['slug']}: {legs[0]['resp']}"); return
    cost = round(sum(l["cost"] for l in filled), 2)
    pos = {"slug": s["slug"], "type": s["type"], "legs": legs, "stake": cost, "predicted_edge": net,
           "entry_price": s.get("ask"), "entry_left": s.get("time_left_sec"),
           "confidence": s.get("confidence"), "move_bps": s.get("move_bps"), "peers": s.get("peers"),
           "buckets": buckets_of(s, s.get("time_left_sec") or 999),
           "ts": now().isoformat(timespec="seconds"), "end": s["end"], "live": is_live()}
    if s["type"] == "MOMENTUM" and pos.get("entry_price") and filled:
        pos["stop_at"] = round(max(P["stop_loss_bid"], P["stop_frac_of_entry"] * pos["entry_price"]), 2)
    state["open_positions"].append(pos)
    state["traded"] = (state.get("traded", []) + [s["slug"]])[-40:]
    if not is_live(): state["bankroll_usd"] -= cost
    decide_log(state, "ENTER", s, stake=cost, shares=sum(l["shares"] for l in filled),
               reason=f"move {s.get('move_bps')} bps, {s.get('peers')} peers agree, paying {s.get('ask')}, "
                      f"{s.get('time_left_sec')}s left, edge {net}")
    partial = " PARTIAL" if len(filled) < len(legs) else ""
    if partial:
        # half an arb is a naked bet. Unwind it this second; only if the sell fails do we keep it as a managed leg.
        leg = filled[0]; ok2, resp2 = sell(leg["token"], leg["shares"])
        if ok2:
            b = state.get("books", {}).get(s["slug"], {}); bid = (b.get("up") or [None, None])[1] if leg["outcome"] == 0 else (b.get("down") or [None, None])[1]
            proceeds = round(leg["shares"] * ((bid if bid else s["up_ask" if leg["outcome"] == 0 else "down_ask"]) - fee(bid or 0.5, P)), 4)
            journal(f"arb half-fill unwound {s['slug']}: sold {leg['shares']} back, ~{proceeds - cost:+.2f}"); notify(f"arb half-fill on {s['slug']} unwound (~{proceeds - cost:+.2f})")
            if not is_live(): state["bankroll_usd"] += proceeds - cost
            state["traded"] = (state.get("traded", []) + [s["slug"]])[-40:]
            return
        pos["type"] = "ARB_LEG"; pos["legs"] = filled          # unwind failed: manage it like a directional trade
    msg = f"{'LIVE' if is_live() else 'PAPER'} {'FORCED' if s.get('forced') else s['type']}{partial} {s['slug']} ${cost} edge {net}" + (f" move {s['move_bps']} bps peers {s['peers']}" if s["type"] == "MOMENTUM" and not s.get("forced") else "")
    journal(msg); notify(msg)

def resolve(slug):
    """Winner index (0=Up, 1=Down) once Gamma marks the market closed, else None."""
    ev = requests.get(f"{GAMMA}/events", params={"slug": slug}, timeout=10).json()
    m = (ev[0].get("markets") or [None])[0] if ev else None
    if not m: return None
    prices = [float(x) for x in json.loads(m.get("outcomePrices", "[]"))]
    return prices.index(max(prices)) if m.get("closed") and prices and max(prices) >= 0.99 else None

def settle_windows(state):
    """Write one line per finished window: open, snapshots, winner. This is the research dataset."""
    t, done = now(), []
    for slug, w in list(state.get("snaps", {}).items()):
        age = (t - parse(w["end"])).total_seconds()
        if age < 60: continue
        try: winner = resolve(slug)
        except Exception as e: log("window resolve err", e); continue
        if winner is None and age < 1800: continue
        with open(WINDOWS_FILE, "a") as f:
            f.write(json.dumps({"slug": slug, "asset": w.get("asset", "btc"), "end": w["end"], "open": w["open"], "winner": winner, "snaps": w["s"]}) + "\n")
        done.append(slug)
    for slug in done: state["snaps"].pop(slug, None)
    return bool(done)

def manage(state, P):
    """Close momentum positions early: lock in near-certain wins, cut clear losers while a bid still exists."""
    keep, changed = [], False
    for p in state["open_positions"]:
        if p["type"] not in ("MOMENTUM", "ARB_LEG") or p.get("no_exit"): keep.append(p); continue
        leg = p["legs"][0]
        left = (parse(p["end"]) - now()).total_seconds()
        b = state.get("books", {}).get(p["slug"])
        bid = ask = None
        if b and abs(b.get("left", 1e9) - left) <= 3:                 # snapshot still current
            bid = b["up"][1] if leg["outcome"] == 0 else b["down"][1]
            ask = b["up"][0] if leg["outcome"] == 0 else b["down"][0]
        else:
            try: ask, _l, bid, _z = top(leg["token"])                 # stale or missing: quote it ourselves
            except Exception as e: log("manage quote err", p["slug"], e)
        if bid is None:      # no bid at all: if the ask is on the floor the market has written this side off
            if ask is not None and ask <= P["stop_loss_bid"] and left >= P["stop_loss_min_left_sec"]: bid = 0.0
            else: keep.append(p); continue
        # (A sibling-stop used to live here. With one bet per direction per window, the only possible sibling is
        # the OPPOSITE side, so forcing it out sold likely winners. Each position now stands on its own price.)
        if is_live() and not p.get("filled_checked") and (now() - parse(p["ts"])).total_seconds() > 12:
            p["filled_checked"] = True
            real = held_shares(leg["token"])
            if real is not None and real > 0 and abs(real - leg["shares"]) > 0.05:
                got = real / leg["shares"] if leg["shares"] else 1
                p["partial_fill"] = round(got, 3)
                p["stake"] = round(p["stake"] * got, 4); leg["shares"] = real
                journal(f"{p['slug']}: filled {got:.0%} of the order ({real:.2f} shares) — position resized to {p['stake']:.2f}")
        p["peak_bid"] = max(p.get("peak_bid", 0.0), bid)          # trailing lock: once it was a near-certain win, don't ride it back down
        # Every exit under two minutes in the record lost — 41 of 41. Entries at 0.51 "fell" to 0.22 in five
        # seconds, which is the book emptying after we took the ask, not the market moving. So: leave a position
        # alone for a grace period, and require the low price to hold for several consecutive scans.
        age = (now() - parse(p["ts"])).total_seconds()
        stop_armed = age >= P["stop_grace_sec"]
        stop_level = max(P["stop_loss_bid"], P["stop_frac_of_entry"] * (p.get("entry_price") or 1))
        if bid <= stop_level and stop_armed:
            p["below"] = p.get("below", 0) + 1
        else:
            p["below"] = 0
        confirmed = p.get("below", 0) >= P["stop_confirm_ticks"]
        reason = "take profit" if bid >= P["take_profit_bid"] else \
                 "profit lock" if (p["peak_bid"] >= P["lock_from_bid"] and bid <= p["peak_bid"] - P["lock_giveback"] and left >= 3) else \
                 "stop loss" if (confirmed and left >= P["stop_loss_min_left_sec"]) else None
        if not reason: keep.append(p); continue
        # Live stops were filling at 0.02 against a 0.25 trigger — that is selling into an empty book for
        # nothing, and 26% of these positions recover. Below this price, hold to resolution instead.
        # Half of all recent losses were stops that filled far below their trigger — the book had emptied, and
        # they all fired at ~48s, the instant the grace period ended. Selling into an empty book recovers almost
        # nothing; holding keeps the chance the prediction was right. So a stop only sells at a real price:
        # within 0.10 of its trigger (the same line classify() uses for "book emptied").
        if reason == "stop loss" and (bid < P["min_sell_bid"] or bid < stop_level - 0.10):
            if not p.get("held_cheap"):
                journal(f"{p['slug']}: bid {bid:.2f} is far under the {stop_level:.2f} stop — book emptied, holding to resolution")
                p["held_cheap"] = True
            keep.append(p); continue
        ok, resp = sell(leg["token"], leg["shares"])
        if ok and is_live():
            # a fill-and-kill sell takes only what the book absorbs; a stop on 2026-09-21 left one share that rode to a loss
            for _ in range(3):
                time.sleep(1.5)
                rem = held_shares(leg["token"])
                # If the API still reports nearly the whole position, it hasn't caught up with our sale yet.
                # Acting on that stale number just fires an order the exchange rejects as "size too small".
                if rem is None or rem < 1 or rem > leg["shares"] * 0.9: break
                ok2, r2 = sell(leg["token"], rem)
                journal(f"{p['slug']}: {rem:.2f} shares left after the exit — sold again {'OK' if ok2 else 'FAILED ' + str(r2)[:50]}")
                if not ok2: break
        if not ok:
            p["sell_fails"] = p.get("sell_fails", 0) + 1
            if p["sell_fails"] in (1, 5): journal(f"sell failed ({reason}) {p['slug']}: {resp}")
            if p["sell_fails"] >= 5: p["no_exit"] = True              # can't exit: quit trying, let it resolve
            keep.append(p); continue
        proceeds = round(leg["shares"] * (bid - fee(bid, P)), 4)
        p["exit_bid"] = bid
        record(state, p, round(proceeds - p["stake"], 4), -2, note=f"{reason} @ {bid:.2f} with {left:.0f}s left")
        if reason == "stop loss": state["bad_cycle"] = [p["slug"].rsplit("-", 1)[-1], leg["outcome"]]
        changed = True
    state["open_positions"] = keep
    return changed

def settle(state):
    t, keep = now(), []
    for p in state["open_positions"]:
        age = (t - parse(p["end"])).total_seconds()
        if age < 45: keep.append(p); continue
        winner = None
        try: winner = resolve(p["slug"])
        except Exception as e:
            state["settle_fails"] = state.get("settle_fails", 0) + 1
            if state["settle_fails"] in (5, 50):
                journal(f"settle failing ({state['settle_fails']}x): {type(e).__name__}: {str(e)[:90]} — positions cannot close")
                notify(f"settle is failing: {type(e).__name__}. Positions stay open and block new trades.")
            log("settle err", e)
        if winner is None:
            if age < 7200: keep.append(p); continue
            pnl, winner = 0.0, -1   # gave up; flag it
        else:
            payout = sum(l["shares"] for l in p["legs"] if l["ok"] and l["outcome"] == winner)
            pnl = round(payout - p["stake"], 4)
        record(state, p, pnl, winner)
    state["open_positions"] = keep

def record(state, p, pnl, winner, note=""):
    if not p["live"]: state["bankroll_usd"] += p["stake"] + pnl
    state["today_pnl_usd"] = round(state["today_pnl_usd"] + pnl, 4)
    st = state["stats"]; st["pnl"] = round(st["pnl"] + pnl, 4); st[p["type"].lower()] = st.get(p["type"].lower(), 0) + 1
    if pnl > 0: st["wins"] += 1; state["consecutive_wins"] += 1; state["consecutive_losses"] = 0
    else: st["losses"] += 1; state["consecutive_losses"] += 1; state["consecutive_wins"] = 0
    state["closed_trades"] += 1
    why = classify(p, pnl, note)
    learn(state, p, pnl, why)
    decide_log(state, "EXIT", {"slug": p["slug"], "type": p["type"], "ask": p.get("entry_price"),
                               "partial_fill": p.get("partial_fill"), "exit_bid": p.get("exit_bid"),
                               "stop_at": p.get("stop_at"), "peak_bid": round(p.get("peak_bid", 0), 3),
                               "move_bps": p.get("move_bps"), "peers": p.get("peers"),
                               "confidence": p.get("confidence")},
               stake=p["stake"], pnl=pnl, exit_reason=note or "settled at expiry", lesson=why,
               held_sec=round((now() - parse(p["ts"])).total_seconds()))
    state["peak_bankroll_usd"] = max(state.get("peak_bankroll_usd", 0), equity(state))
    rec = {"ts": p["ts"], "slug": p["slug"], "type": p["type"], "stake": p["stake"], "pnl": pnl,
           "predicted_edge": p["predicted_edge"], "winner": winner, "live": p["live"], "note": note,
           "entry_price": p.get("entry_price"), "confidence": p.get("confidence"), "move_bps": p.get("move_bps"), "peers": p.get("peers")}
    with open(TRADES_FILE, "a") as f: f.write(json.dumps(rec) + "\n")
    msg = f"{'sold' if winner == -2 else 'closed'} {p['type']} {p['slug']} pnl {pnl:+.2f}{' (' + note + ')' if note else ''} | today {state['today_pnl_usd']:+.2f} | bankroll {state['bankroll_usd']:.2f}"
    journal(msg); notify(msg)

_relay_fail = 0
def relay_alive():
    """True if the relay answers /health. Three misses in a row block live trading and ping once; recovery unblocks."""
    global _relay_fail, LIVE_BLOCKED
    url = relay_url()
    ok = False
    if url:
        try: ok = bool((requests.get(url + "/health", headers=_bypass_headers(), timeout=10).json() or {}).get("ok"))   # a login page is not "ok"
        except Exception: ok = False
    _relay_fail = 0 if ok else _relay_fail + 1
    if not ok and _relay_fail == 3 and not LIVE_BLOCKED and os.path.exists("LIVE"):
        LIVE_BLOCKED = True; journal("relay offline — live blocked"); notify("Relay offline (Vercel). Trading paused until it answers again.")
    if ok and LIVE_BLOCKED and os.path.exists("LIVE"):
        LIVE_BLOCKED = False; journal("relay back — live resumed"); notify("Relay back. LIVE resumed.")
    return ok

def redeem_ctf(pos):
    """Redeem a resolved binary CTF position on-chain without the SDK's market lookup.
    SDK path: redeem_positions(condition_id) -> list_markets(condition_ids=..) -> the 5-min series isn't
    listed -> UserInputError "No market found". The call it would then build is reproduced here."""
    from polymarket._internal.actions.relayer.calls import ctf_redeem_positions_call
    c = pm(); cfg = c._ctx.environment_config
    adapter = cfg.neg_risk_collateral_adapter if pos.get("negativeRisk") else cfg.collateral_adapter
    call = ctf_redeem_positions_call(ctf=adapter, collateral=cfg.collateral_token, condition_id=pos["conditionId"])
    return c._dispatch_single_call(call, metadata=f"Redeem {pos['conditionId'][:12]}")

def sweep_redeem(state):
    """Winnings on Polymarket sit as resolved shares until redeemed; the cash balance (and our sizing) ignores them.
    Every few minutes, claim everything the Data API marks redeemable. h.wait() has no timeout of its own and
    blocks on-chain confirmation — a stuck transaction hung the whole bot for 3+ hours on 2026-09-18. Bounded
    with a thread join so a slow confirmation delays this sweep, never the trading loop."""
    if not is_live(): return
    try:
        r = requests.get("https://data-api.polymarket.com/positions", params={"user": os.environ["POLY_FUNDER"], "sizeThreshold": 0, "limit": 100}, timeout=15).json()
    except Exception as e:
        state["redeem_fail"] = state.get("redeem_fail", 0) + 1
        if state["redeem_fail"] in (1, 12): journal(f"redeem sweep: positions API failed ({type(e).__name__}: {str(e)[:80]})")
        return
    claimed = 0; failures = []
    todo = [p for p in (r if isinstance(r, list) else []) if p.get("redeemable") and float(p.get("size", 0)) > 0]
    # dust from rounding (< 0.05 shares) is not worth a transaction
    todo = [p for p in todo if float(p.get("currentValue") or 0) >= 0.05]   # resolved losers and rounding dust are worth nothing
    if todo and state.get("redeem_seen") != len(todo):
        journal(f"redeem sweep: {len(todo)} position(s) waiting to be claimed, worth ~{sum(float(p.get('currentValue') or 0) for p in todo):.2f}")
        state["redeem_seen"] = len(todo)
    for pos in todo:
        try:
            h = redeem_ctf(pos)
            done = threading.Event(); outcome = {}
            def _wait():
                try: h.wait()
                except Exception as e: outcome["err"] = e
                finally: done.set()
            th = threading.Thread(target=_wait, daemon=True); th.start()
            if not done.wait(timeout=25):
                failures.append("timed out on-chain"); continue
            if "err" in outcome: raise outcome["err"]
            claimed += 1; journal(f"claimed {pos.get('title', pos['conditionId'][:10])}: {float(pos['size']):.2f} shares")
        except Exception as e:
            failures.append(f"{type(e).__name__}: {str(e)[:90]}")
    if claimed: notify(f"claimed winnings on {claimed} market(s)")
    if failures:
        state["redeem_errs"] = state.get("redeem_errs", 0) + 1
        if state["redeem_errs"] in (1, 6, 36):     # the reason must reach the journal, not just stdout nobody can read
            journal(f"redeem FAILED on {len(failures)} position(s): {failures[0]}")
            worth = sum(float(p.get("currentValue") or 0) for p in todo)
            notify(f"Winnings of ~${worth:.2f} need claiming in the Polymarket app (Portfolio → Redeem). Auto-claim needs a Builder API key.")
    else:
        state["redeem_errs"] = 0

def check_relay(state):
    """Prove the relay path end to end: /health (which region answers) and a balance read through it."""
    url = relay_url()
    if not url: journal("relay: none"); notify("relay: none — orders from GitHub are geoblocked"); return
    try:
        h = requests.get(url + "/health", headers=_bypass_headers(), timeout=15); region = (h.json() or {}).get("region", "?") if h.ok else f"HTTP {h.status_code}"
    except Exception as e: region = f"unreachable: {str(e)[:80]}"
    global _pm; _pm = None
    try: bal = f"balance via relay {live_balance():.2f}"
    except Exception as e: bal = f"balance via relay FAILED: {str(e)[:100]}"
    msg = f"relay {url.split('/')[2]} region {region} | {bal}"
    journal(msg); notify(msg)

def redispatch():
    """GitHub's cron is unreliable on quiet repos: start the next run ourselves when this one ends."""
    pat, repo = os.environ.get("GH_PAT"), os.environ.get("GITHUB_REPOSITORY")
    if not (pat and repo): return
    try:
        r = requests.post(f"https://api.github.com/repos/{repo}/actions/workflows/survivor.yml/dispatches",
                          headers={"Authorization": f"Bearer {pat}", "Accept": "application/vnd.github+json"},
                          json={"ref": "main"}, timeout=10)
        log("redispatch", r.status_code)
    except Exception as e: log("redispatch failed", e)

# ---------- loop ----------
def main():
    global LIVE_BLOCKED
    P = params()
    state = load_json(STATE_FILE, None)
    def fresh_state():
        global LIVE_BLOCKED
        if os.path.exists("LIVE") and not relay_url():
            LIVE_BLOCKED = True
            journal("LIVE requested but RELAY file is empty — orders from GitHub are geoblocked; paper until it is set")
            notify("LIVE waiting: no relay URL in the RELAY file. Paper until it is set.")
        elif os.path.exists("LIVE"):
            try:
                b = live_balance()
                if b < HARD["floor_usd"] + 1:
                    LIVE_BLOCKED = True
                    try: diagnose_funds()
                    except Exception as e: journal(f"funds check failed: {str(e)[:100]}")
                    journal(f"LIVE requested but Polymarket balance is {b:.2f} (need > {HARD['floor_usd'] + 1:.0f}) — paper until funds land")
                    notify(f"LIVE waiting: Polymarket balance reads {b:.2f}. Paper until it's above {HARD['floor_usd'] + 1:.0f}. Rechecking every minute.")
                else:
                    st = new_state(b); st["live_mode"] = True
                    journal(f"LIVE mode on. Polymarket balance {b:.2f}"); notify(f"LIVE. Real money. Balance {b:.2f}. {int(HARD['max_trade_pct']*100)}% per trade, {HARD['max_open_positions']} positions, {int(HARD['max_exposure_pct']*100)}% total exposure.")
                    return st
            except Exception as e:
                LIVE_BLOCKED = True
                journal(f"LIVE requested but Polymarket auth/balance failed: {str(e)[:120]} — staying on paper"); notify(f"LIVE blocked: {str(e)[:120]}. Running paper until fixed.")
        st = new_state(50.0); st["live_mode"] = False; return st
    if state and state.get("mode") in ("DEAD", "HIBERNATE") and state.get("bankroll_usd", 0) > HARD["floor_usd"] \
            and state.get("today_pnl_usd", 0) > -HARD["daily_loss_cap_usd"]:
        journal(f"resuming from {state['mode']}: the limit that stopped it no longer applies"); state["mode"] = "CAUTIOUS"
    if state is None or (state.get("mode") == "DEAD" and state.get("bankroll_usd", 0) <= 0) or bool(state.get("live_mode")) != os.path.exists("LIVE"):
        state = fresh_state(); commit(state, "survivor: startup")
    try: rebuild_lessons()
    except Exception as e: log("rebuild lessons err", e)
    if os.path.exists("LIVE"): state["relay_seen"] = relay_url(); check_relay(state)
    t0 = time.time(); last_pull = last_commit = last_bal = time.time(); last_sweep = 0; scans = 0; dirty = False
    scan_errs, last_err = 0, ""
    notify(f"run start {'LIVE' if is_live() else 'PAPER'} bankroll {state['bankroll_usd']:.2f} mode {state['mode']}")
    consecutive_faults = 0
    while time.time() - t0 < RUN_SECONDS:
      try:
          if os.path.exists("HALT"):
              journal("HALT found, exiting"); notify("HALT — stopped"); break
          day_roll(state)
          if is_live() and time.time() - last_sweep > 300:
              try: sweep_redeem(state)
              except Exception as e: log("sweep err", e)
              last_sweep = time.time()
          if os.path.exists("LIVE") and time.time() - last_bal > 60:
              try:
                  if not relay_alive(): raise RuntimeError("relay offline")
                  b = live_balance()
                  if LIVE_BLOCKED and relay_url() and b >= HARD["floor_usd"] + 1 and not state["open_positions"]:
                      LIVE_BLOCKED = False; commit(state, "survivor: funds landed"); state = fresh_state(); P = params(); dirty = True
                  elif is_live():
                      # The earlier guard rejected any drop bigger than open stakes + $1. But a closed losing trade
                      # has no open stake, so every real loss looked "impossible" and the agent sized off a phantom
                      # $36 while the account held $3 (2026-09-22). Now: reject only 0.00, and accept a big move
                      # once a second read agrees with it — a glitch doesn't repeat, a real balance does.
                      prev = state.get("bankroll_usd", 0) or 0
                      if b <= 0:
                          state["bad_reads"] = state.get("bad_reads", 0) + 1
                          log("ignoring zero balance read, kept", prev)
                      elif prev > 0 and abs(prev - b) > 1.0 and abs((state.get("pending_read") or -99) - b) > 0.5:
                          state["pending_read"] = b          # big change: wait for one confirming read
                          log("balance moved", prev, "->", b, "— confirming on next read")
                      else:
                          if prev > 0 and abs(prev - b) > 1.0:
                              journal(f"balance confirmed {prev:.2f} -> {b:.2f}")
                          state["bad_reads"] = 0; state["pending_read"] = None
                          state["bankroll_usd"] = b
              except Exception as e: log("balance err", e)
              last_bal = time.time()
          pass
          before = state["closed_trades"]
          try: settle(state)
          except Exception as e: log("settle err", e)
          dirty |= state["closed_trades"] != before
          try: dirty |= settle_windows(state)
          except Exception as e: log("settle_windows err", e)
          set_mode(state)
          if state["mode"] == "DEAD":
              journal(f"DEAD at bankroll {state['bankroll_usd']:.2f}. Post-mortem: stats {state['stats']}")
              notify("DEAD. Floor breached. Trading stopped permanently."); commit(state, "survivor: DEAD"); return
          try:
              sigs = scan(state, P); scans += 1; scan_errs = 0
          except Exception as e:
              sigs, scan_errs, last_err = [], scan_errs + 1, f"{type(e).__name__}: {str(e)[:120]}"
              log("scan err", last_err)
              if scan_errs in (5, 100, 1000):
                  journal(f"scan failing ({scan_errs} in a row): {last_err}"); notify(f"scan failing: {last_err}")
              time.sleep(5)
          try: dirty |= manage(state, P)          # runs even when the scan failed: a held position must never go unwatched
          except Exception as e: log("manage err", e)
          for s, stake, net in decide(state, P, sigs):
              execute(state, s, stake, net, P); dirty = True
          if time.time() - last_pull > PULL_EVERY:
              try: pull(); P = params()
              except Exception as e: log("pull err", e)
              last_pull = time.time()
              if relay_url() != state.get("relay_seen"):
                  state["relay_seen"] = relay_url()
                  try: check_relay(state)
                  except Exception as e: log("relay check err", e)
              if bool(state.get("live_mode")) != is_live() and not state["open_positions"]:
                  commit(state, "survivor: mode switch"); state = fresh_state(); P = params(); dirty = True
          if dirty or time.time() - last_commit > COMMIT_EVERY:
              d = state.get("diag", {})
              journal(f"heartbeat{'' if is_live() else ' [paper/explore]'}: {scans} scans, {len(state['open_positions'])} open, mode {state['mode']}, "
                      f"bankroll {state['bankroll_usd']:.2f}, markets {d.get('markets')}/{d.get('in_window')} in window across {d.get('assets')}, "
                      f"best up+down {d.get('best_sum')} on {d.get('slug')}, opens {len(state['opens'])}, "
                      f"blocked by {d.get('blocked')}, closest {d.get('closest')}"
                      + (f", last error {last_err}" if scan_errs else ""))
              try: commit(state)
              except Exception as e: log("commit err", e)
              last_commit = time.time(); dirty = False
          if RESTART:
              journal("code updated on main, restarting on next run"); notify("code updated, restarting")
              commit(state, "survivor: restart for new code"); redispatch(); return
          time.sleep(0.3 if state.get("diag", {}).get("hot") else 1)

      except Exception as e:
          consecutive_faults += 1
          log("loop fault", type(e).__name__, str(e)[:120])
          if consecutive_faults in (10, 100):
              journal(f"loop fault x{consecutive_faults}: {type(e).__name__}: {str(e)[:100]}")
              notify(f"agent hitting repeated errors: {type(e).__name__}. Still running.")
          time.sleep(2); continue
      consecutive_faults = 0
    journal(f"run end: {scans} scans, mode {state['mode']}, bankroll {state['bankroll_usd']:.2f}, "
            f"today {state['today_pnl_usd']:+.2f}, open {len(state['open_positions'])}, stats {state['stats']}")
    commit(state, "survivor: run end")
    if state["mode"] != "DEAD" and not os.path.exists("HALT"): redispatch()

if __name__ == "__main__":
    main()
